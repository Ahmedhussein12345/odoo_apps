# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from datetime import datetime


class AmountPay(models.TransientModel):
    _name = 'amount.amount.pay'
    _description = 'amount wizard payment'


    amount = fields.Char(dafault=0.0, required=True)
    name = fields.Char("اسم العريس", required=True)
    date_today = fields.Date(string='Date', default=datetime.today())

    def action_confirm(self):
        active_id_here = self._context.get('active_id')
        obj2=self.env['reservation.management'].browse(active_id_here)
        print(obj2.groom_names.name)
        obj1 = self.env['account.payment']
        print(obj1.name)
        object_created=obj1.create({
            'payment_type': 'inbound',
            'partner_type': 'customer',
            'partner_id': obj2.groom_names.id,
            'amount': self.amount,
            'has_invoices': True,
            'payment_method_id': 1,
            'communication': 'Hello ' + str(self.name),
            'journal_id': 6,
            # 'payment_method_id': 2,
            'payment_date': self.date_today,


        })
        print(obj1.name)


        object_created.post()



