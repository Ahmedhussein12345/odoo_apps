# -*- coding: utf-8 -*-
from datetime import timedelta
from odoo import models, fields, api, _
import  datetime
import calendar
from odoo.exceptions import ValidationError



class AmountPay(models.Model):
    _inherit = 'account.move'

    @api.constrains('name', 'journal_id', 'state')
    def _check_unique_sequence_number(self):
        moves = self.filtered(lambda move: move.state == 'posted')
        if not moves:
            return

        self.flush()

        # /!\ Computed stored fields are not yet inside the database.
        self._cr.execute('''
               SELECT move2.id
               FROM account_move move
               INNER JOIN account_move move2 ON
                   move2.name = move.name
                   AND move2.journal_id = move.journal_id
                   AND move2.type = move.type
                   AND move2.id != move.id
               WHERE move.id IN %s AND move2.state = 'posted'
           ''', [tuple(moves.ids)])
        res = self._cr.fetchone()
        # if res:
        #     raise ValidationError(_('Posted journal entry must have an unique sequence number per company.'))


class AccountPaymentInherit(models.Model):

    _inherit = 'account.payment'

    payment_method_id = fields.Many2one('account.payment.method',
                                        string='Payment Method',
                                        required=False,
                                        readonly=True,
                                        states={'draft': [('readonly', False)]},)


class ReservationManagement(models.Model):

    _name = 'reservation.management'
    _description = 'New Reservation Record'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _rec_name = 'groom_names'
    day = fields.Char(compute="_get_day",store=True)
    currency_id = fields.Many2one('res.currency', string='Currency',
                                  default=lambda self: self.env.company.currency_id)
    summution = fields.Float(readonly=True)
    baqy = fields.Float(readonly=True)

    @api.constrains('period_id', 'date_request')
    def _check_unique_date_period(self):
        for rec in self:
            record = rec.search([('period_id', '=', rec.period_id.id), ('id', '!=', rec.id),('state','!=','cancel')])
            record2 = rec.search([('date_request', '=', rec.date_request), ('id', '!=', rec.id),('state','!=','cancel')])
            if record and record2:
                raise ValidationError(_('هناك حفلة محجوزة في هذا التاريخ '))


    @api.depends('date_request')
    def _get_day(self):

        ara = calendar.day_name[self.date_request.weekday()]
        print(calendar.day_name[self.date_request.weekday()])
        if ara == 'Saturday':
            self.day = 'السبت'
        elif ara == 'Sunday':
            self.day = 'الاحد'
        elif ara == 'Monday':
            self.day = 'الاثنين'
        elif ara == 'Tuesday':
            self.day = 'الثلاثاء'
        elif ara == 'Wednesday':
            self.day = 'الاربعاء'
        elif ara == 'Thursday':
            self.day = 'الخميس'
        elif ara == 'Friday':
            self.day = 'الجمعه'

    name = fields.Char("Name")
    name_seq = fields.Char(string='Reservation ID', required=True, copy=False, readonly=True,
                           index=True, default=lambda self: _('New'))
    # groom_name = fields.Char('Name of The Groom')


    groom_names = fields.Many2one('res.partner', 'Name of The Groom',required=True)
    groom_family_name = fields.Char('Name Of Groom Family')
    date_request = fields.Date(string='Reservation Date',default=fields.Date.context_today,required=True)
    period_id = fields.Many2one('settings.periods', string="Period",required=True)
    value_of_3rboons = fields.Float('Value initially',required=True)
    value_of_contracts = fields.Float('Value of Contract',compute='get_value_contracts',store=True)
    num_man = fields.Integer('Number of Men')
    num_woman = fields.Integer('Number of Woman')
    hfla_bnood = fields.One2many('hfla.bnod','hafla_id')
    state = fields.Selection([
        ('draft', 'حجز مبدئي'),
        ('done', 'حجز مؤكد'),
        ('confirmed', 'حجز نهائي'),
        ('cancel', 'حجز ملغي'),
    ], string='Status', default="draft",
        copy=False, index=True, readonly=True, tracking=True,
    )


    @api.model
    def create(self, vals):
        if vals.get('name_seq', _('New')) == _('New'):
            vals['name_seq'] = self.env['ir.sequence'].next_by_code('reservation.management.sequence') or _('New')
        result = super(ReservationManagement, self).create(vals)
        return result

    def process_confirmed(self):
        action = self.env.ref('partycom.amount_payment_wizard').read()[0]
        action['views'] = [(self.env.ref('partycom.amount_action_wizard_form_view').id, 'form')]
        action['context'] = {
            'default_name': self.groom_names.name,

        }
        action['target'] = 'new'



        return action


    def process_confirm(self):
       self.state='done'

    def process_done_state(self):
        obj1 = self.env['account.payment']
        self.state = 'confirmed'
        created=obj1.create({
            'payment_type': 'inbound',
            'partner_type': 'customer',
            'partner_id': self.groom_names.id,
            'amount': self.value_of_3rboons,
            'communication': 'Hello ' + str(self.groom_names.name),
            'journal_id': 6,
            'has_invoices': True,
            'payment_method_id': 1,
            # 'payment_method_id': self.id,

        })
        created.post()


        lines = []
        for rec in self.hfla_bnood:
            lines.append((0, 0, {
                'name': rec.description,
                'account_id': rec.product_id.categ_id.property_account_income_categ_id.id,
                'price_unit': rec.price,
                'quantity': rec.qty,
                'discount': 0.0,
                'product_uom_id': rec.product_id.uom_id.id,
                'product_id': rec.product_id.id,
            }))

        account_move = self.env['account.move'].create({
            'partner_id': self.groom_names.id,
            'type': 'out_invoice',
            'invoice_date': self.date_request,
            'invoice_payment_term_id': 1,
            'invoice_line_ids': lines,
        })

        account_move.action_post()

    def open_customer_payments(self):
        return {
            'name': 'Payments',
            'domain': [('partner_id', '=', self.groom_names.name)],
            'res_model': 'account.payment',
            'view_id': False,
            'view_mode': 'tree,form',
            'type': 'ir.actions.act_window',
        }



    def process_cancel_state(self):
        for rec in self:
            rec.state = 'cancel'



    @api.onchange('groom_names','value_of_contracts','total_payments','write_uid')
    def total_payment(self):
        payments = self.env['account.payment'].search([('partner_id','=',self.groom_names.name)])
        s=0
        for rec in payments:
            s += rec.amount
        self.total_payments = s
        self.baqy = self.value_of_contracts - self.total_payments

    @api.depends('hfla_bnood.price_subtotal')
    def get_value_contracts(self):
           for order in self:
               s=0
               for line in order.hfla_bnood:
                   s += line.price_subtotal
                   order.update({
                       'value_of_contracts': s,
                   })





    total_payments = fields.Float(default=0,readonly=True)

    # @api.onchange('value_of_contracts','total_payments')
    # def get_baqy(self):
    #     self.baqy = self.value_of_contracts - self.total_payments

    def process_draft_state(self):
        for rec in self:
            rec.state = 'draft'


class ProductTemplateInherit(models.Model):
    _inherit = 'product.template'
    name = fields.Char('Name', default="حجز صالة", index=True, required=True, translate=True)
    type = fields.Selection([
        ('consu', 'Consumable'),
        ('service', 'Service')], string='Product Type', default='service', required=True,
        help='A storable product is a product for which you manage stock. The Inventory app has to be installed.\n'
             'A consumable product is a product for which stock is not managed.\n'
             'A service is a non-material product you provide.')

    list_price = fields.Float(
        'Sales Price', default=0.0,
        digits='Product Price',
        help="Price at which the product is sold to customers.")

    purchase_ok = fields.Boolean('Can be Purchased', default=False)

