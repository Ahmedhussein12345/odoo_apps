# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class PriceLists(models.Model):
    _name = 'pricelist.pricelist'
    _description = 'New Price Lists Record'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char('Name')
 #    name = fields.Char("Name")
 #    name_seq = fields.Char(string='Reservation ID', required=True, copy=False, readonly=True,
 #                           index=True, default=lambda self: _('New'))
 #    # groom_name = fields.Char('Name of The Groom')
 #    groom_names = fields.Many2one('res.partner', 'Name of The Groom')
 #    groom_family_name = fields.Char('Name Of Groom Family')
 #    date_request = fields.Date(string='Reservation Date')
 #    value_of_3rboons = fields.Float('Value initially')
 #    value_of_contracts = fields.Float('Value of Contract')
 #    num_man = fields.Integer('Number of Men')
 #    num_woman = fields.Integer('Number of Woman')
 #    hfla_bnood = fields.One2many('hfla.bnod', 'product_id')
 #    state = fields.Selection([
 #        ('draft', 'Draft'),
 #        ('confirmed', 'Confirm'),
 #        ('done', 'Done'),
 #        ('cancel', 'Cancelled'),
 #    ], string='Status', default="draft",
 #        copy=False, index=True, readonly=True, tracking=True,
 #        help=" * Draft: The transfer is not confirmed yet. Reservation doesn't apply.\n"
 #             " * Waiting another operation: This transfer is waiting for another operation before being ready.\n"
 #             " * Done: The transfer has been processed.\n"
 #             " * Cancelled: The transfer has been cancelled.")
 #