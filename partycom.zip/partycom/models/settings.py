# -*- coding: utf-8 -*-
from odoo import models, fields, api, _

class SettingsRecords(models.Model):
    _name = 'settings.settings'
    _description = 'Hall Settings'
    name = fields.Char('Name')
    people_number = fields.Float('People Number')
    hall_type = fields.Char('Hall Type')

class SettingsPeriodsRecords(models.Model):
    _name = 'settings.periods'
    _description = 'Periods Settings'
    name = fields.Char('Period Name')
    start_hour = fields.Char('Start')
    end_hour = fields.Char('End')
