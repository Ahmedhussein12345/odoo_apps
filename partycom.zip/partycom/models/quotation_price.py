# -*- coding: utf-8 -*-

from odoo import models, fields, api,_


class WeddingPartyQuotationPrice(models.Model):
    _name = 'wedding.quotation'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']

    name = fields.Char(string="Groom Name")
    family_groom = fields.Char(string="Family Groom")
    inviters_number = fields.Integer(string="Inviters Number")
    period = fields.Many2one('settings.periods',string="Period")
    reservation_type = fields.Selection([
        ('during_weak', 'During The Weak'),
        ('last_weak', 'During The WeakEnd')
    ],string="Reservation Type")
    product_id = fields.Many2one('product.template',string="Reservation Item")