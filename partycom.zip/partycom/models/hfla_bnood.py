# -*- coding: utf-8 -*-
from odoo import models, fields, api

from datetime import date
import calendar

class HflaBnood(models.Model):
    _name = 'hfla.bnod'
    _description = 'hfla bnood'
    name = fields.Char("Name")
    # products = fields.Many2one('reservation.management')
    hafla_id=fields.Many2one('reservation.management')
    product_id = fields.Many2one('product.product',string="Product")
    description = fields.Char("Description")
    qty = fields.Float("Qty")
    price = fields.Float("Price")
    price_subtotal = fields.Float("Total",compute="_get_total",store=True,readonly=True)

    @api.depends('product_id','qty','price')
    def _get_total(self):
        for rec in self:
            rec.price_subtotal = rec.qty * rec.price
            curr_date = date.today()
            print(calendar.day_name[curr_date.weekday()])

