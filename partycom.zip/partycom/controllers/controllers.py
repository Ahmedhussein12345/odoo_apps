# -*- coding: utf-8 -*-
# from odoo import http


# class Partycom(http.Controller):
#     @http.route('/partycom/partycom/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/partycom/partycom/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('partycom.listing', {
#             'root': '/partycom/partycom',
#             'objects': http.request.env['partycom.partycom'].search([]),
#         })

#     @http.route('/partycom/partycom/objects/<model("partycom.partycom"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('partycom.object', {
#             'object': obj
#         })
